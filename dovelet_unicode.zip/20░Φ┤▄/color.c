#include <iostream>
using namespace std;

int white=0, pink=0;
int p[555][555];

int plus(int x1, int y1, int x2, int y2){
    int i,j,sum=0;
    for (i=y1;i<=y2;i++){
        for (j=x1;j<=x2;j++){
            sum=sum+p[i][j];
        }
    }
    return sum;
}

void f(int x1, int y1, int x2, int y2){
    int k;
    k=plus(x1,y1,x2,y2);
    if (k==0){

    }else if (k==((x2-x1+1)*(y2-y1+1))){

    }
    int s1=(x1+x2)/2, s2=(y1+y2)/2;
    f(x1,y1,s1,s2);
    f(s1+1, y1, x2, s2);
    f(x1, s2+1, s1, y2);
    f(s1+1, s2+1, x2, y2);
}

int main()
{
    cin >> n;
    int i,j;
    for (i=1;i<=n;i++){
        for (j=1;j<=n;j++){
            cin >> p[i][j];
        }
    }
    f(1,1,n,n);
}
