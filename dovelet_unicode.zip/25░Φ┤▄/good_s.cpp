#include <iostream>
using namespace std;

int n;
int seq[111];
int flag;

inline int check_seq(int a, int b, int c, int d){
    //if (b-a!=d-c)
        //return -1;
    int count=0;
    for (int j=0;j<=b-a;j++){
        if (seq[a+j]!=seq[c+j])
            return 0;
    }
    return 1;
}

void back(int k){
    if (flag)
        return;
    for (int i=1;i<=(k/2);i++)
    {
        if (check_seq(k-2*i,k-i-1,k-i, k-1)==1)
            return;
    }
    if(k==n)
    {
        for (int i=0;i<n;i++){
            cout << seq[i];
        }
        flag=1;
        return;
    }
    seq[k]=1;
    back(k+1);
    seq[k]=2;
    back(k+1);
    seq[k]=3;
    back(k+1);
}
int main()
{
    cin >> n;
    back(0);
    return 0;
}
