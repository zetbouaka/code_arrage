#include <iostream>
using namespace std;

int n,m;
int d[55], le[55], ri[55];
int solution;
int E1, E2;

inline int abs(int u)
{
    if (u<0)
        return -u;
    return u;
}

inline int max(int a, int b)
{
    if (a<b)
        return b;
    return a;
}

void greedy()
{
    int a=E1, b=E2, greedy_solution;
    for (int i=1;i<=n;i++)
    {
        if ((abs(b-d[i]>abs(a-d[i]))))
        {
            greedy_solution+=abs(a-d[i]);
            a=d[i];
        }else{
            greedy_solution+=abs(b-d[i]);
            b=d[i];
        }
    }
    solution=greedy_solution;
}

void back(int left, int right, int p_sol)
{
    if (p_sol>=solution)
        return;
    int u=max(left, right)+1;
    if (u==n+1)
    {
        solution=p_sol;
        return;
    }
    back(u, right, p_sol+abs(le[left]-d[u]));
    back(left, u, p_sol+abs(ri[right]-d[u]));
}

int main()
{
    cin >> m;
    cin >> E1 >> E2;
    cin >> n;
    int i;
    for (i=1;i<=n;i++){
        cin >> d[i];
        le[i]=d[i];
        ri[i]=d[i];
    }
    le[0]=E1;
    ri[0]=E2;
    greedy();
    back(0,0,0);
    cout << solution;
}
