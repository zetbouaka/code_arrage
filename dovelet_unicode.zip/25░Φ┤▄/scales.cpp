#include <iostream>
#include <algorithm>
using namespace std;

int p[33];
int n;
int sum;
int count_scales;

void back(int k, int scales)
{
    int j;
    for (j=k;j<n;j++)
    {
        if (scales+p[j]==sum){
            count_scales++;
        }
        if (scales+p[j]<sum){
            back(j+1, scales+p[j]);
        }
    }
}

int main()
{
    cin >> n;
    for (int i=0;i<n;i++){
        cin >> p[i];
        sum=sum+p[i];
    }
    if (sum%2==1)
    {
        cout << "impossible";
    }
    else{
        sum=sum/2;
        sort(p, p+n);
        back(0, 0);
        if (count_scales==0){
            cout << "impossible";
        }else{
            cout << count_scales;
        }
    }
}
