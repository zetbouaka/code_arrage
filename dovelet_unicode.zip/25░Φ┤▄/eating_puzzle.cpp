#include <iostream>
#include <algorithm>
using namespace std;

int ans;
int bound,n;
int a[55];

void back(int pre, int k)
{
 int i;
 if (pre>bound)
  return;
 if (pre>ans)
  ans=pre;
 for (i=n;i>=k;i--){
  back(pre+a[i], i+1);
 }
}

int main()
{
 cin >> bound >> n;
 int i;
 for (i=0;i<n;i++){
  cin >> a[i];
 }
 sort(a, a+n);
 for (i=0;i<n;i++){
  if (ans<a[i] && bound>a[i])
   ans=a[i];
 }
 back(0, 0);
 cout << ans;
}
