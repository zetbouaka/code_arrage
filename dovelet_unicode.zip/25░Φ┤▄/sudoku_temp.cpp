#include <iostream>
#include <string>

using namespace std;

int sudoku[11][11];
bool flag;
bool check[11];
bool check_x[11][11];

inline bool check_sudoku(int x, int y)
{
    int i,j,k;
    if (check_x[y][sudoku[y][x]]>1 || check_y[x][sudoku[y][x]]>1)
        return false;
    for (i=1;i<=9;i++)
        check[i]=false;
    for (i=0;i<9;i++)
    {
        if (check[sudoku[y][i]] && sudoku[y][i]>0){
            return false;
        }
        check[sudoku[y][i]]=true;
    }
    for (i=1;i<=9;i++)
        check[i]=false;
    for (i=0;i<9;i++)
    {
        if (check[sudoku[i][x]] && sudoku[i][x]>0)
            return false;
        check[sudoku[i][x]]=true;
    }
    for (i=1;i<=9;i++)
        check[i]=false;
    int sx=(x/3), sy=(y/3);
    bool flag2=false;
    sx=sx*3, sy=sy*3;
    for (i=0;i<3;i++)
    {
        for (j=0;j<3;j++){
            if (check[sudoku[sy+i][sx+j]] && sudoku[sy+i][sx+j]>0)
                return false;
            check[sudoku[sy+i][sx+j]]=true;
        }
    }
    return true;
}

void back(int x, int y)
{
    if (flag)
        return;
    if (x==9 && y==8){
        short int i,j;
        for (i=0;i<9;i++)
        {
            for (j=0;j<9;j++)
            {
                cout << sudoku[i][j];
            }
            cout << endl;
        }
        flag=true;
        return;
    }
    if (x==9)
    {
        back(0, y+1);
        return;
    }
    if (sudoku[y][x]==0)
    {
        int i;
        for (i=1;i<=9;i++)
        {
            sudoku[y][x]=i;
            check_x[y][i]++;
            check_y[x][i]++;
            if (check_sudoku(x,y)){
                back(x+1, y);
            }
            check_x[y][i]--;
            check_y[x][i]--;
            sudoku[y][x]=0;
        }
    }
    else
    {
        back(x+1,y);
    }
}

int main()
{
    string str;
    int i,j;
    for (i=0;i<9;i++)
    {
        getline(cin,str);
        for (j=0;j<9;j++)
        {
            sudoku[i][j]=str[j]-'0';
        }
    }
    back(0,0);
}
