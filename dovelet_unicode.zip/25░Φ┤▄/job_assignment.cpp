#include <iostream>
#include <queue>
using namespace std;

int p[55][55];
int max_p[55][55], check_p[55][55];
int n;
int ans;
int bound[55];
int check[55];
int stack[55], path[55];

void greedy_search()
{
    int max=0, sum=0;
    int i,j;
    for (i=n;i>=1;i--){
        max=0;
        for (j=1;j<=n;j++){
            if (max<p[i][j])
                max=p[i][j];
        }
        sum=sum+max;
        bound[i]=sum;
    }
    sum=0;
    for (i=1;i<=n;i++)
    {
        max=0;
        for (j=1;j<=n;j++){
            if (p[i][max]<p[i][j] && check[j]==0)
                max=j;
        }
        sum=sum+p[i][max];
        check[max]=1;
        path[i]=max;
    }
    ans=sum;
    for (i=1;i<=n;i++)
        check[i]=0;
}

void back(int k, int sol)
{
    int i, j;
    if ((sol + bound[k]) <= ans){
        return;
    }
    if (k==(n+1)){
        if (ans<sol){
            ans=sol;
            for (i=1;i<=n;i++)
                path[i]=stack[i];
        }
        return;
    }
    for (j=1;j<=n;j++)
    {
        i=max_p[k][j];
        if (check[i]==0){
            check[i]=1;
            stack[k]=i;
            back(k+1, sol+p[k][i]);
            stack[k]=0;
            check[i]=0;
        }
    }
}

int main()
{
    cin >> n;
    int i,j,k;
    for (i=1;i<=n;i++){
        for (j=1;j<=n;j++){
            cin >> p[i][j];
        }
    }
    int mcp;
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=n;j++)
        {
            mcp=0;
            for (k=1;k<=n;k++)
            {
                if (p[i][k]>p[i][mcp] && check_p[i][k]==0)
                    mcp=k;
            }
            max_p[i][j]=mcp;
            check_p[i][mcp]=1;
        }
    }
    greedy_search();
    back(1, 0);
    cout << ans << endl;
    for (i=1;i<=n;i++)
        cout << path[i] << " ";
}
