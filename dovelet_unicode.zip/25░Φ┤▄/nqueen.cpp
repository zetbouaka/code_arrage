#include <iostream>
using namespace std;

int count;
int n;
int col[15];
int check[15];
int ldia[555],rdia[555];

void nqueen(int r){
    int i;
    if (r>n){
        count++;
        if (count > 3){
            return;
        }
        for (i=1;i<=n;i++){
            cout << col[i] << " ";
        }
        cout << endl;
        return;
    }
    for (i=1;i<=n;i++){
        if (check[i]==1 || ldia[i-r+n]==1 || rdia[i+r]==1) continue;
        check[i]=1;
        ldia[i-r+n]=1;
        rdia[i+r]=1;

        col[r]=i;
        nqueen(r+1);

        check[i]=0;
        ldia[i-r+n]=0;
        rdia[i+r]=0;

    }
}

int main()
{
    cin >> n;
    nqueen(1);
    cout << count;
}
