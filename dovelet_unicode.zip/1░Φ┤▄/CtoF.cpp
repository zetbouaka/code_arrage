#include <stdio.h>

int main()
{
    int c;
    scanf("%d",&c);
    double d;
    d=9/5.0*c+32;
    printf("%.1lf", d);
    return 0;
}
