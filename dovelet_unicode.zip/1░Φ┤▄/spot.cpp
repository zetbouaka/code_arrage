#include <stdio.h>

int main()
{
    double d,r,p;
    r=100;
    scanf("%lf %lf",&d,&p);
    double k=d*(100+p)/100;
    printf("%.3lf",d-k);
    return 0;
}
