#include <stdio.h>

int main()
{
    int sum=0,a;
    int i;
    for (i=0;i<4;i++)
    {
        scanf("%d",&a);
        sum=sum+a;
    }
    printf("%.2lf", (double)(sum)/4);
    return 0;
}
