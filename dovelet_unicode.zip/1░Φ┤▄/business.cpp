#include <iostream>
using namespace std;

int main()
{
    int n,m,p,c;
    cin >> n >> m >> p >> c;
    cout << (n-m+p);
}
