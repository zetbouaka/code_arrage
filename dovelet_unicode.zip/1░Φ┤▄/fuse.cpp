#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int a,b,c;
    cin >> a >> b >> c;
    double d;
    d=ceil((5*a+4*b+c)/10.0)*10;
    cout << (int)d << " amperes";
}
