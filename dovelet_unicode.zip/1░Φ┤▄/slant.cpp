#include <iostream>
using namespace std;
int main()
{
    int a,b,c,d;
    cin >> a >> b;
    cin >> c >> d;
    int m=(d-b)/(c-a);
    cout << m << " " << b-m*a;
}
