#include <iostream>
using namespace std;

int main()
{
    long long n;
    long long m;
    cin >> n;
    n=n/2+1;
    m=6*n*n-9;
    cout << m;
    return 0;
}
