#include <iostream>
using namespace std;

int main()
{
    int m;
    cin >> m;
    int k;
    k=m/(24*60*60);
    cout << k << " ";
    m=m%(24*60*60);
    k=m/(60*60);
    cout << k << " ";
    m=m%(60*60);
    k=m/(60);
    cout << k << " ";
    cout << m%60;
    return 0;
}
