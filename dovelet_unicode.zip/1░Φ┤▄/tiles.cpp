#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int n,m,u;
    cin >> n >> m;
    if (n>m)
        u=m,m=n,n=u;
    double t1=0,t2=0,t3=0;
    if (n%8>0)
        t1=ceil(m/8.0);
    if (m%8>0)
        t2=ceil(n/8.0);
    if (n%8>0 && m%8>0)
        t3=1;
    cout << "The number of whole tiles is " << floor(n/8.0)*floor(m/8.0) << " part tiles is " << t1+t2-t3;
    return 0;
}
