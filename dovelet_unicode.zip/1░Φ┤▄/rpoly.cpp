#include <stdio.h>
#include <math.h>

int main()
{
    double r,n;
    scanf("%lf %lf",&r,&n);
    printf("%.3lf",r*r*sin(2*3.1415926535/n)/2*n);
    return 0;
}
