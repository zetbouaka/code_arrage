#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int a,b;
    cin >> a >> b;
    int i=sqrt(a)-1,count=0;
    while(1)
    {
        if (i*i>b)
            break;
        if (i*i>=a)
        {
            count++;
        }
        i++;
    }
    cout << (b-a)+1-count;
    return 0;
}
