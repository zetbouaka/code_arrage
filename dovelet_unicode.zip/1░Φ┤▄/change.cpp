#include <iostream>
using namespace std;

int main()
{
    int m;
    cin >> m;
    m=1000-m;
    cout << m/100 << " ";
    m=m-(m/100)*100;
    cout << m/50 << " ";
    m=m-(m/50)*50;
    cout << m / 10;
    return 0;
}
