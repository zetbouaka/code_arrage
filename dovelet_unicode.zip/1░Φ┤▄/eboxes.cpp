#include <iostream>
using namespace std;

int main()
{
    long long n,k,t,f;
    cin >> n >> k >> t >> f;
    long long u=1,y=0;
    int count=1;
    while((n-1)+u<f && count<=t)
    {
        y=y+u;
        u=u*k;
        count++;
    }
    y=y+u;
    long long s1=0,s2=0;
    long long i=1,l=u;
    //cout << y<<" " << u << endl;
    //return 0;
    while(1)
    {
        if ((n-1+u+(l-u)/k)<=f)
        {
            f=f-(u+(l-u)/k);
            s1=s1+y;
            n=n-1;
            //cout << "EE!" << endl;
        }
        else
        {
            y=y-k;
            u=u-k;
            if (u==0)
            {
                l=l/k,u=l;
            }
            //l++;
            //y=y-u;
            //u=u/k;
        }
        if (n==0)
            break;
        //cout << u << " " << y << " " << f << endl;
    }
    cout << s1;
    return 0;
}

//other solution :
//if add fulled box, plus K after minus one.
//
