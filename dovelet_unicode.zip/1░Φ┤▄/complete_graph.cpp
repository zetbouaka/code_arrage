#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    cout << (n*(n-1)/2);
    return 0;
}
