#include <iostream>
using namespace std;

int main()
{
    int a,b,c;
    cin >> a >> b >> c;
    int s=a+b+c;
    cout << 4*s - 24;
}
