#include <stdio.h>
#define PI 3.14159

int main()
{
    double a,b;
    scanf("%lf %lf",&a,&b);
    double c=PI*a+PI*b+1.414213*(a+b);
    printf("%.3lf",c);
    return 0;
}
