#include <iostream>
using namespace std;

int main()
{
    int m;
    cin >> m;
    cout << m << " minutes";
    cout << " is " << (m*60) << " seconds.";
    return 0;
}
