#include <iostream>
using namespace std;
long long k;

int main()
{
    int n,m,i;
    cin >> n >> m;
    k=1;
    for (i=0;i<n;i++)
        k=k*m;
    cout << k;
    return 0;
}
