#include<iostream>
using std::cin;using std::cout;
int main(){
int a, b;
cin >> a >> b;
cout << a;
return 0;
}
