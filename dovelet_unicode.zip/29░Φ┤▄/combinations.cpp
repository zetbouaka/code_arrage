#include <iostream>
using namespace std;

unsigned long long int f(int n, int m){
    if (m==1)
        return n;
    return f(n-1,m-1)*n/m;
}

int main()
{
   int n,r;

   cin >> n >> r;

   cout << n << " things taken " << r << " at a time is " << f(n, r) << " exactly." << endl;
}

