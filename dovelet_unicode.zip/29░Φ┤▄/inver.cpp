#include <iostream>
using namespace std;

int visit[111];
int stack[111];
int inver[111];
int data[111][111];
int n;

void print()
{
    int i,j;
    for (i=1;i<=n;i++){
        //cout << stack[i] << " " ;
    }
    int count=0;
    for (i=1;i<=n;i++){
        for (j=1;j<=n;j++){
            if (i<j && stack[i]>stack[j])
                count++;
        }
    }
    if (inver[count]==0)
    {
        inver[count]=1;
        for (i=1;i<=n;i++)
        {
            data[count][i]=stack[i];
        }
    }
    //cout << count << endl;
}
void dfs(int k)
{
    if (k==n){
        print();
        return;
    }
    int i;
    for (i=1;i<=n;i++){
        if (visit[i]==0){
            visit[i]=1;
            stack[k+1]=i;
            dfs(k+1);
            stack[k+1]=0;
            visit[i]=0;
        }
    }
}
int main()
{
    cin >> n;
    dfs(0);
    int i,j;
    for (i=0;i<=n*(n-1)/2;i++){
        for (j=1;j<=n;j++){
            cout << data[i][j] << " ";
        }
        cout << endl;
    }
}
