#include <iostream>
#include <math.h>
using namespace std;

long long int prime[11111], table[11111];
long long int prime_number;

int main()
{
    int n;
    cin >> n;
    int i,j,k=0,f=0;
    int sum=n*(n+1)/2;
    for (i=1;i<=n;i++){
        prime[i]=i;
    }
    table[0]=0;
    for (i=1;i<=n;i++)
    {
        for (j=sum;j>=0;j--){
            if (j-prime[i]<=0)
                break;
            table[j]=(table[j]+table[j-prime[i]]);
        }
        table[prime[i]]=table[prime[i]]+1;
    }
    //if ((sum/2)%2==1){
    //    cout << 0;
    //}else{
    if (sum%2==1)
        table[sum/2]=0;
        cout << table[sum/2]/2;
    //}
}
