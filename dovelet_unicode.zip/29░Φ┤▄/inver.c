#include <iostream>
using namespace std;

int visit[111];
int stack[111];
int n;

void print()
{
    int i,j;
    for (i=1;i<=n;i++){
        cout << stack[i] << " " ;
    }
    int count=0;
    for (i=1;i<=n;i++){
        for (j=1;j<=n;j++){
            if (i<j && stack[i]>stack[j])
                count++;
        }
    }
    cout << count << endl;
}
void dfs(int k)
{
    if (k==n+1){
        print();
        return;
    }
    for (i=1;i<=n;i++){
        if (visit[i]==0){
            visit[i]=1;
            stack[k+1]=i;
            dfs(k+1);
            stack[k+1]=0;
            visit[i]=0;
        }
    }
}
int main()
{
    cin >> n;
    dfs(0);
}
