#include <iostream>
using namespace std;

int main()
{
    int n;
    int i,k;
    while(cin >> n){
        k=1;
        for (i=2;i<=n;i++){
            k=k*i;
            while(k%10==0 && k>10){
                k=k/10;
            }
            k=k%10;
        }
        cout << fixed << setprecision(5) << k;
    }
}
