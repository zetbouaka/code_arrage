#include <iostream>
#define O 5000000
using namespace std;

int n,m;
bool table1[11111111], table2[11111111];
int chu[111115];

int main()
{
    int i,j;
    cin >> n;
    for (i=1;i<=111111;i++)
    {
        chu[i]=i;
    }
    //process
    table1[O]=1;
    int k;
    for (i=1;i<=111111;i++)
    {
        k=i*(i+1)/2;
        for (j=O-k;j<=O+k;j++)
        {
            if (table1[j]){
                table2[j+chu[i]]=1, table2[j-chu[i]]=1;
            }
        }
        k=(i+1)*(i+2)/2;
        for (j=O-k;j<=O+k;j++)
        {
            table1[j]=table2[j];
            table2[j]=0;
        }
        if (table1[O+n])
        {
            cout << i;
            return 0;
        }
    }
}
