#include <iostream>
using namespace std;

int n,start;
int g[11][11];
int v[11];
int stack[11];
int solve=0;

void dfs(int top, int pv)
{
    int i;
    for (i=1;i<=n;i++)
    {
        if (v[i]==0 && g[pv][i])
        {
            cout << " " << i;
            v[i]=1;
            dfs(top+1, i);
        }
    }
}

int main()
{
    cin >> n >> start;
    int a,b;
    while (cin >> a >> b)
    {
        if (a==0 && b==0)
            break;
        g[a][b]=1;
        g[b][a]=1;
    }
    v[start]=1;
    stack[1]=start;
    cout << start;
    dfs(1, start);
}
