#include <iostream>
#include <algorithm>
#include <queue>
using namespace std;

queue<int> Q;
int P[311111];
int N, K;

int main()
{
    cin >> N >> K;
    Q.push(N);
    int V, i;
    for (i=0;i<=100000;i++)
        P[i]=999999;
    P[N]=0;
    while(!Q.empty())
    {
        V=Q.front();
        if (V == K)
            break;
        //cout << V << endl;
        if(0<=V && V<=100000){
            if(V+1<=100000 && P[V+1]==999999){
                Q.push(V+1);
                P[V+1]=P[V]+1;
            }
            if(0<=V-1 && P[V-1]==999999){
                Q.push(V-1);
                P[V-1]=P[V]+1;
            }
            if(V*2<=100000 && P[V*2]==999999){
                Q.push(V*2);
                P[V*2]=P[V]+1;
            }
        }
        Q.pop();
    }
    cout << P[K];
}
