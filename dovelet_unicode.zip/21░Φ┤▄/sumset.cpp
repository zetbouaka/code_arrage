#include <iostream>
#include <math.h>
using namespace std;

long long int table[11111111];
long long int p[11111];

int main()
{
    int n;
    cin >> n;
    int i,j,k=0,f=0;
    int sum=n*(n+1)/2;
    p[1]=1;
    for (i=2;i<=log2(n)+1;i++){
        p[i]=p[i-1]*2;
    }
    table[0]=1;
    for (i=1;i<=log2(n)+1;i++)
    {
        for (j=0;j<=n;j++){
            table[j+p[i]]+=table[j];
            table[j+p[i]]=table[j+p[i]]%1000000000;
        }
    }
    cout << table[n];
}
