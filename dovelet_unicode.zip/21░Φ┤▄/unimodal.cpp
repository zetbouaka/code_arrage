#include<stdio.h>

int main()
{
     int n,i,j,k;
     long long int t[255][130];

     scanf("%d",&n);
     t[0][0]=1;

     for(i=1;i<=n;i++)
     {
          t[i][0]=t[0][i]=1;

          for(j=1;j<=i/2;j++)
          {
               t[i][j]=0;

               if(i-j*2>=j||i-j*2==0)
               {
                    t[i][j]++;
                    for(k=j;k<=(i-j*2)/2;k++)
                         t[i][j]+=t[i-j*2][k];
               }

               t[0][i]+=t[i][j];
          }
     }

     printf("%lld",t[0][n]);

     return 0;
}
