#include <iostream>
using namespace std;

int p[1111];
int table[1111][4][33];
int n, m;

int max(int a,int b){
    if (a>b)
        return a;
    return b;
}
int main(){
    cin >> n >> m;
    int i,j,k;
    for (i=1;i<=n;i++){
        cin >> p[i];
    }
    table[0][1][0]=1;
    for (i=0;i<=n;i++){
        for (k=1;k<=2;k++){
            for (j=0;j<=m;j++){
                if (table[i][k][j]){
                    table[i+1][p[i+1]][j+1]=max(table[i+1][p[i+1]][j+1], table[i][k][j]+1);
                    table[i+1][k][j]=max(table[i+1][k][j], table[i][k][j]+(k==p[i+1]));
                }
            }
        }
    }
    int ans=0;
    for (i=0;i<=m;i++){
        ans=max(ans, table[n][1][i]);
        ans=max(ans, table[n][2][i]);
    }
    cout << ans-1;
}
