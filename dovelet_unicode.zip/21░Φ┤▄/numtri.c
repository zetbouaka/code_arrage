#include <iostream>
using namespace std;

int g[1111][1111];
int t[1111][1111];

int max(int a,int b){
    if (a>b)
        return a;
    else
        return b;
}

int main(){
    int r;
    cin >> r;
    for (i=0;i<r;i++){
        for (j=0;j<i;j++){
            cin >> g[i][j];
        }
    }
    t[0][0]=g[0][0];
    for (i=1;i<r;i++){
        t[i][0]=g[i][0]+t[i-1][0];
        for (j=1;j<i;j++){
            t[i][j]=g[i][j]+max(t[i-1][j-1], t[i-1][j]);
        }
    }
    int max_sum=0;
    for (i=0;i<r;i++){
        max_sum=max(max_sum, t[r-1][i]);
    }
    cout << max_sum;
}
