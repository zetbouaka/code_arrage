#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;

int so[9999];
int prime[9999], pn;

int main()
{
    int n;
    int i,k,j,u,check;
    pn=0;
    for (i=2;i<=9999;i++)
    {
        check=0;
        for (j=2;j<=sqrt(i);j++)
        {
            if (i%j==0 && i!=j)
                check=1;
        }
        if (check==0)
        {
            prime[pn]=i;
            pn++;
        }
    }
    cin >> n;
        k=1;
        for (i=0;i<pn;i++)
        {
            so[i]=0;
        }
        for (i=2;i<=n;i++){
            u=i;
            for (j=0;j<pn;j++)
            {
                if (prime[j]>u)
                    break;
                while((u%prime[j])==0)
                {
                    u=u/prime[j];
                    so[j]=so[j]+1;
                }
            }
        }
        if (so[0]<so[2]){
            so[2]=so[2]-so[0];
            so[0]=0;
        }else{
            so[0]=so[0]-so[2];
            so[2]=0;
        }
        for (i=0;i<pn;i++)
        {
            if (so[i]>0){
                for (j=1;j<=so[i];j++){
                    k=k*prime[i];
                    k=k%10;
                }
            }
        }
        cout << k;

}
