//20101516 JinDaeYoon
#include <iostream>
#include <algorithm>
using namespace std;

int n;
int table1[33][33], table2[33][33];

class member{
    public:
    int a, b;
}p[1111];

int sortfunction(member s1, member s2)
{
    if (s1.a<s2.a)
        return 1;
    return 0;
}
int main()
{
    int a,b;
    n=-1;
    while (cin >> a >> b){
        if (a==0 && b==0)
            break;
        n++;
        p[n].a=a;
        p[n].b=b;
    }
    sort(p, p+n, sortfunction);
    int i,j,k;
    table1[1][0]=p[0].a;
    table1[0][1]=p[0].b;
    //cout << n;
    for (k=1;k<=n;k++){
        if (table2[1][0]<p[k].a)
            table2[1][0]=p[k].a;
        if (table2[0][1]<p[k].b)
            table2[0][1]=p[k].b;
        for (i=0;i<=15;i++){
            for (j=0;j<=15;j++){
                if (table1[i][j]){
                    if (table1[i][j]+p[k].a>table2[i+1][j])
                        table2[i+1][j]=table1[i][j]+p[k].a;
                    if (table1[i][j]+p[k].b>table2[i][j+1])
                        table2[i][j+1]=table1[i][j]+p[k].b;
                }
            }
        }
        for (i=0;i<=15;i++){
            for (j=0;j<=15;j++){
                if (table1[i][j]<table2[i][j])
                    table1[i][j]=table2[i][j];
                table2[i][j]=0;
            }
        }
    }
    cout << table1[15][15];
    //cout << table1[1][1];
}
