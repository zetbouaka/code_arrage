#include <iostream>
using namespace std;

long long table[33][33];
long long table_sum[33][33];
long long n,m,u;
char bit[33];

int main()
{
    cin >> n >> m >> u;
    table[1][0]=1;
    table[1][1]=1;
    int i,j;
    for (i=2;i<=n;i++){
        table[i][0]=1;
        for (j=1;j<=i;j++){
            table[i][j]=table[i-1][j]+table[i-1][j-1];
        }
    }
    table_sum[1][0]=1;
    table_sum[1][1]=1;
    for (i=1;i<=n;i++){
        table_sum[i][0]=1;
        for (j=1;j<=n;j++){
            table_sum[i][j]=table_sum[i][j-1]+table[i][j];
        }
    }
    int k=0;
    //u=u-1;
    //cout << table_sum[2][2] << endl;
    while(n>0){
        //cout << u << " " << table_sum[n-1][m] << endl;
        if (u<=table_sum[n-1][m] || u==1 && n==1){
            bit[k]='0', n--;
            cout << "0";
        }else{
            u=u-table_sum[n-1][m];
            bit[k]='1', n--, m--;
            cout << "1";
        }
        k++;
    }
    //for (i=0;i<n;i++){
        //cout << bit[i];
    //}
}
