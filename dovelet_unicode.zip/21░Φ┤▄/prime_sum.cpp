#include <iostream>
#include <math.h>
using namespace std;

int prime[11111], table[11111];
int prime_number;

int main()
{
    int n;
    cin >> n;
    int i,j,k=0,f=0;
    for (i=2;i<=n;i++){
        k=sqrt(i);
        f=0;
        for (j=2;j<=k;j++)
        {
            if (i%j==0){
                f=1;
                break;
            }
        }
        if (f==0){
            prime_number++;
            prime[prime_number]=i;
            //table[i]=1;
        }
    }
    table[0]=0;
    for (i=1;i<=prime_number;i++)
    {
        for (j=n;j>=0;j--){
            if (j-prime[i]<=0)
                break;
            table[j]=(table[j]+table[j-prime[i]])%123456789;
        }
        table[prime[i]]=table[prime[i]]+1;
    }
    cout << table[n]%123456789;
}
