#include <iostream>
#include <algorithm>
#include <math.h>
using namespace std;

int p[111];
bool table[111][(101)*(100)+1], table2[111][(101)*(100)+1];

int abs(int u)
{
    if (u<0)
        return -u;
    return u;
}

int min_f(int a,int b)
{
    if (a>b)
        return b;
    else
        return a;
}
int main()
{
    int n, m=0;
    cin >> n;
    int i,j,k=0,f=0;
    for (i=1;i<=n;i++){
        cin >> p[i];
        m=m+p[i];
    }
    sort(p, p+n);
    table[0][0]=1;
    for (i=1;i<=n;i++)
    {
        table[0][0]=1;
        for (k=0;k<i;k++){
            for (j=0;j<=m;j++){
                if(table[k][j])
                    table2[k+1][j+p[i]]=1;
            }
        }
        for (k=0;k<i;k++){
            for (j=0;j<=m;j++){
                table[k][j]|=table2[k][j];
                table2[k][j]=0;
            }
        }
    }
    int u, min=99999999, min2=0;
    if (n%2==1)
    {
        u=(n+1)/2;
    }
    else{
        u=n/2;
    }
    for (i=0;i<=m;i++)
    {
        if (table[u][i]){
            k=abs((m-i)-i);
            if (min>k){
                min=k, min2=i;
                //cout << u << " " << i << endl;
            }
        }
    }
    min=min2;
    if (min>(m-min))
        min=m-min;
    cout << min << " " << m-min;
}
