#include <iostream>
using namespace std;

class Date
{
  private:
    int year;
    int month;
    int day;

    // static member variable that keeps track of
    // how many instances were created.
    static int dateCount;

  public:
    // default constructor
    Date();

    // constructor
    Date(int y, int m, int d);

    // copy constructor
    Date(const Date& that);

    // 1 argument constructor
    // Initialize a Time object using char array "yyyy:mm:dd"
    // If the string doesn't follow the yyyy:mm:dd format,
    // set the year, month, and day to 0.
    Date(char date[]);

    // destructor
    ~Date();

    // static member function that returns how many Date objects are in memory.
    static int getDateCount();

    // Overloaded + operator that adds two times.
    Date operator+(const int d) const;

    // Overloaded - operator returns the number of days between
    // current date and the passed Date that
    int operator-(const Date& that) const;

    // Overloaded - operator returns a Date before n days
    Date operator-(const int n) const;

    // don't worry about the following function.
    // we will discuss operator<< overloading later
    friend std::ostream& operator<<(std::ostream& out, const Date& t){
        out << t.year << ":" << t.month << ":" << t.day ;
        return out;
    }
};

int Date::dateCount = 0;

Date::Date()
{
    year = 1900;
    month = 1;
    day = 1;
    //dateCount++;
}

Date::Date(int y, int m,int d)
{
    year = y; month = m; day = d;
    //dateCount++;
}

Date::Date(const Date& that)
{
    year = that.year; month = that.month; day = that.day;
    //dateCount++;
}

Date::Date(char date[])
{
    year = (date[0]-'0')*1000+(date[1]-'0')*100+(date[2]-'0')*10+(date[3]-'0');
    month = (date[5]-'0')*10+(date[6]-'0');
    day = (date[8]-'0')*10+(date[9]-'0');
    //dateCount++;
}

Date::~Date()
{
    //dateCount--;
}

int Date::getDateCount()
{
    return dateCount;
}

Date Date::operator+(const int d) const
{
    int mon[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
    Date sum;
    sum.year=this->year; sum.month=this->month; sum.day=this->day;
    sum.day=sum.day+d;
    if (sum.day>mon[this->month])
    {
        sum.day=sum.day-mon[this->month];
        sum.month++;
    }
    if (sum.month>12)
    {
        sum.month=sum.month-12;
        sum.year++;
    }
    return sum;
}

int Date::operator-(const Date& that) const
{
    if (this->day-that.day<0)
    {
        Date sub;
        sub.year=this->year; sub.month=this->month; sub.day=this->day;
        int mon[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
        while((sub.day-that.day)<0){
            sub.day=sub.day+mon[sub.month];
            sub.month--;
        }
        return sub.day-that.day;
    }else{
        return this->day-that.day;
    }
}

Date Date::operator-(const int n) const
{
    Date sub;
    sub.year=this->year; sub.month=this->month; sub.day=this->day;
    sub.day=sub.day-n;
    if (sub.day<0)
    {
        int mon[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
        while(sub.day<0){
            sub.day=sub.day+mon[sub.month];
            sub.month--;
        }
    }
    return sub;
}

int main(int argc, char* argv[])
{
   Date d1(2012,3,30);

   if(true){
       Date d2(d1);
       Date d3 = d2 + 3;
       Date d4("2012:03:12");

       cout << d2 << endl;
       cout << d3 << endl;
       cout << d4 << endl;
       //cout << Date::getDateCount() << endl;
   }
   //cout << Date::getDateCount() << endl;

   Date d5 = d1 - 3;

   cout << d1 - d5 << endl;
   cout << d5 << endl;

   cout << Date::getDateCount() << endl;
}

