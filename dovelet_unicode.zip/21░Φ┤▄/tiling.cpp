#include <iostream>
using namespace std;

unsigned long long n, t[333];

int main()
{
    cin >> n;
    t[1]=1;
    t[2]=3;
    for (int i=3;i<=n;i++){
        t[i]=2*t[i-2]+t[i-1];
    }
    cout << t[n];
}
