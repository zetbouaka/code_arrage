#include <iostream>
using namespace std;

int div[111][111];
int table[111][111];
int data[111];
int path[111][111];
int path_table[111];
int n, m;

int main(){
    cin >> n;
    cin >> m;
    int i,j,k;
    for (i=0;i<n;i++){
        cin >> data[i];
    }
    int min, max;
    for (i=0;i<n;i++){
        min=data[i], max=data[i];
        for (j=i;j<n;j++){
            if (data[j]<min)
                min=data[j];
            if (data[j]>max)
                max=data[j];
            div[i][j]=max-min;
        }
    }
    for (i=0;i<n;i++)
    {
        table[1][i]=div[0][i];
        path[1][i]=i;
    }
    for (k=2;k<=m;k++){
        for (i=0;i<n;i++){
            for (j=0;j<=i-2;j++){
                if ((table[k-1][j]+div[j+1][i])>table[k][i])
                {
                    table[k][i] = table[k-1][j]+div[j+1][i];
                    path[k][i]=j;
                }
            }
        }
    }
    int maxk=1, maxi=1;
    for (i=0;i<n;i++){
        if (table[m][i]>table[m][maxi])
        {
            maxi=i;
        }
    }
    cout << table[m][maxi];
}
