#include <iostream>
using namespace std;

class IntVal
{
public:
static int getValCount()
{
return valCount;
}
private:
int value;
static int valCount;
};

int IntVal::valCount = 0;

int main()
{
    cout << IntVal::getValCount();
}
