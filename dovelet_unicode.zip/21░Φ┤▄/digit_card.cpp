#include <iostream>
#include <string.h>
using namespace std;

char Num[55];
int n;
int table[55];
int check[55];

void back(int k){
    if (k<=1)
    {
        return;
    }
    if (check[k])
        return;
    if ((Num[k-1]-'0')*10+(Num[k]-'0')<=34 && Num[k-1]!='0' && Num[k]!='0'){
        back(k-1);
        back(k-2);
        table[k]=table[k-2]+table[k-1];
        //cout << k << ':' << Num[k] << ':' << table[k] << endl;
    }
    else{
        if (Num[k]=='0' && Num[k-1]=='0'){
            table[k]=0;
        }else{
            if (Num[k]=='0' && (Num[k-1]-'0')<=3){
                back(k-2);
                table[k]=table[k-2];
            }
            else{
                back(k-1);
                table[k]=table[k-1];
            }
        }
        //cout << k << ':' << Num[k] << ':' << table[k] << endl;
    }
    check[k]=1;
}

int main()
{
    cin >> Num;
    n=strlen(Num);
    table[0]=1;
    check[0]=1;
    check[1]=1;
    if (n>=2)
    {
        if ((Num[0]-'0')*10+(Num[1]-'0')<=34 && (Num[0]-'0')!=0 && (Num[1]-'0')!=0)
            table[1]=2;
        else
            table[1]=1;
    }else{
        table[1]=1;
    }
    back(n-1);
    for (int i=2;i<n;i++)
    {
        //back(i);
        //cout << table[i] << endl;
    }
    cout << table[n-1];
    //cout << table[2];
}
