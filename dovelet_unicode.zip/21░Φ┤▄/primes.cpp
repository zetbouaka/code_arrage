#include <iostream>
#include <math.h>
using namespace std;

int n;
int p[11111];
int table[10005][2222], table2[10005][2222];
int ans[11111];

int main()
{
    int i,j,flg=0;
    p[1]=2;
    p[2]=3;
    n=2;
    for (i=4;i<=10000;i++){
        flg=0;
        for (j=1;j<=n;j++){
            if(i%p[j]==0)
                flg=1;
            if (sqrt(i)<p[j])
                break;
        }
        if (flg==0){
            n++;
            p[n]=i;
        }
    }
    table[0][0]=1;
    int sum=0;
    for (i=1;i<=n;i++){
        sum=sum+p[i];
        if (sum>10000)
            sum=10000;
        table[0][0]=1;
        table[p[i-1]][i-1]=1;
        for (j=p[i];j<=sum;j++){
            if (table[j-p[i]][i-1])
                table2[j][i]+=table[j-p[i]][i-1];
        }
        for (j=0;j<=sum;j++){
            table[j][i]=table2[j][i];
            ans[j]+=table[j][i];
        }
    }
    sum=0;
    for (i=2;i<=n;i++)
        ans[p[i]]++;
    int m;
    while(1){
        cin >> m;
        if (m==0)
            return 0;
        cout << ans[m] << endl;
    }
}
