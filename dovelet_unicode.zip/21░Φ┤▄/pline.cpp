#include <iostream>
using namespace std;

int div[11111][11111];
int table[11111][11111];
int data[11111];
int flg[11111][11111];
int n, m, u;

int main(){
    cin >> m >> n;
    int i,j,k;
    int sum=-1;
    u=1;
    for (i=1;i<=n;i++){
        cin >> data[i];
    }
    sum=-1;
    for (i=1;i<=n;i++)
    {
        sum=sum+data[i]+1;
        if (sum>m)
        {
            u++;
            sum=data[i]-1;
        }
    }
    for (i=1;i<=n;i++){
        sum=-1;
        for (j=i;j<=n;j++){
            sum=sum+data[j]+1;
            if (sum>m)
                break;
            div[i][j]=(m-sum)*(m-sum);
            flg[i][j]=1;
        }
    }
    for (i=1;i<=n;i++)
    {
        table[1][i]=div[1][i];
    }
    for (k=2;k<=u*2;k++){
        for (i=1;i<=n;i++){
            for (j=0;j<=i-1;j++){
                if (flg[j+1][i]==0 || table[k-1][j]==0)
                    continue;
                if ((table[k-1][j]+div[j+1][i])<table[k][i] || table[k][i]==0)
                {
                    table[k][i] = table[k-1][j]+div[j+1][i];
                }
            }
        }
    }
    int maxk=1, maxi=n;
    for (k=1;k<=u*2;k++){
        if ((table[k][n]<table[maxk][n] && table[k][n]>0) || table[maxk][n]==0)
        {
            maxk=k;
            maxi=n;
        }
        //cout << table[k][n] << endl;
    }
    //cout << table[4][10];
    cout << table[maxk][maxi];
}
