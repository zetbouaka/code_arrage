#include <iostream>
using namespace std;

int n,m;
int table[33][33];

inline int function(int i, int j)
{
    if (i==j)
        table[i][j]=1;
    if (j==0)
        return 1;
    if (table[i][j]>0)
        return table[i][j];
    return function(i-1, j-1)+function(i-1, j);
}
int main()
{
    cin >> n >> m;
    table[1][0]=1;
    table[1][1]=1;
    int sum=0, i, j;
    for (i=1;i<=n;i++){
        table[i][i]=1;
        table[i][0]=1;
    }
    for (i=2;i<=n;i++){
        for (j=1;j<=i;j++)
        {
            table[i][j]=table[i-1][j-1]+table[i-1][j];
        }
    }
    for (i=0;i<=m;i++){
        //table[n][i]=function(n, i);
        sum = sum + table[n][i];
        //cout << table[n][i] << endl;
    }
    cout << sum;
}
