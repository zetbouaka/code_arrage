#include <iostream>
using namespace std;

int n, m;
int table[333][333];
int div[333][333];
int path[333][333];
int p[333];

int max(int a,int b)
{
    if (a>b)
        return a;
    return b;
}

int main()
{
    cin >> n >> m;
    int i,j,k;
    for (i=1;i<=n;i++){
        cin >> p[i];
    }
    int sum=0;
    for (i=1;i<=n;i++){
        sum=0;
        for (j=i;j<=n;j++){
            sum=sum+p[j];
            div[i][j]=sum;
        }
    }
    for (i=1;i<=n;i++)
    {
        table[1][i]=div[1][i];
    }
    for (k=2;k<=m;k++){
        for (i=1;i<=n;i++){
            table[k][i]=214748347;
            for (j=1;j<=i-1;j++){
                if (table[k][i]>max(table[k-1][j], div[j+1][i]))
                {
                    table[k][i]=max(table[k-1][j], div[j+1][i]);
                    path[k][i]=j;
                }
            }
        }
    }
    cout << table[m][n] << endl;
    int path_table[333], u=n;
    i=m;
    path_table[i]=n;
    while(i>0){
        u=path[i][u];
        i--;
        path_table[i]=u;
    }
    for (i=0;i<m;i++){
        cout << (path_table[i+1]-path_table[i]) << " ";
    }
}
