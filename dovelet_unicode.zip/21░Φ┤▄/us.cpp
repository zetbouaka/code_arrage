#include <iostream>
using namespace std;

int g[11111];
int t[11111],p[11111];
int n;

int main(){
    cin >> n;
    int i,j;
    for (i=0;i<n;i++)
    {
        cin >> g[i];
    }
    int max, maxi;
    t[0]=1;
    p[0]=0;
    for (i=1;i<n;i++)
    {
        maxi=i;
        for (j=0;j<i;j++)
        {
            if (g[j]<g[i] && t[maxi]<t[j]){
                maxi=j;
            }
        }
        t[i]=t[maxi]+1;
        p[i]=maxi;
    }
    maxi=0;
    for (i=0;i<n;i++)
    {
        if (t[maxi]<t[i])
            maxi=i;
    }
    int stack[11111], u=maxi, l=0;
    while(1){
        stack[l]=u;
        l++;
        if (u==p[u])
        {
            break;
        }
        u=p[u];
    }
    cout << t[maxi] << endl;
    for (i=l-1;i>=0;i--)
        cout << g[stack[i]]<< " ";

}
