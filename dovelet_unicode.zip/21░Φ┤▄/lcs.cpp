#include <iostream>
using namespace std;

int A[1111], B[1111];
int table[1111][1111], path1[1111][1111], path2[1111][1111];
int n, m;
int stack[1111];

int main(){
    cin >> n >> m;
    int i,j;
    for (i=1;i<=n;i++)
    {
        cin >> A[i];
    }
    for (i=1;i<=m;i++){
        cin >> B[i];
    }
    int max, maxi;
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=m;j++){
            if (table[i][j]<=table[i][j-1])
                table[i][j]=table[i][j-1], path1[i][j]=i, path2[i][j]=j-1;
            if (table[i][j]<=table[i-1][j])
                table[i][j]=table[i-1][j], path1[i][j]=i-1, path2[i][j]=j;
            if (A[i]==B[j]){
                if (table[i][j]<=(table[i-1][j-1]+1))
                    table[i][j]=table[i-1][j-1]+1, path1[i][j]=i-1, path2[i][j]=j-1;
            }
        }
    }
    cout << table[n][m] << endl;
    i=n;
    j=m;
    int cnt=0, ni, nj;
    while(1){
        if (A[i]==B[j])
            stack[++cnt]=A[i];
        ni=path1[i][j];
        nj=path2[i][j];
        i=ni, j=nj;
        if (i==0 && j==0)
            break;
    }
    for (i=cnt;i>=1;i--){
        cout << stack[i] << " ";
    }
}
