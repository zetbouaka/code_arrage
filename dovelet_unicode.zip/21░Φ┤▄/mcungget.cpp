#include <iostream>
#include <math.h>
using namespace std;

long long int table[1111111];
long long int p[111];

int main()
{
    int n;
    cin >> n;
    int i,j,k=0,f=0;
    int sum=n*(n+1)/2;
    for (i=1;i<=n;i++){
        cin >> p[i];
    }
    table[0]=1;
    for (i=1;i<=n;i++)
    {
        for (j=0;j<=65540;j++){
            table[j+p[i]]|=table[j];
        }
    }
    int max=0;
    for (i=1;i<=65536;i++){
        if (table[i]==0)
            max=i;
    }
    if (max==65535)
        max=0;
    cout << max;
}
