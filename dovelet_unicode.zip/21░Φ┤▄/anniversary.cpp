#include <iostream>
#include <vector>
using namespace std;

#define MAX(a, b) (((a) > (b)) ? (a) : (b)).

vector <int> g[6666];
int table1[6666], table2[6666], check1[6666], check2[6666];
int check[6666], p[6666];
int j, n;

int f1(int);
int f2(int);

int f1(int k){
    //k�� ����
    if (check1[k])
        return table1[k];
    for (int i=0;i<g[k].size();i++)
    {
        j=g[k][i];
        table1[k]+=f2(j);
    }
    check1[k]=1;
    table1[k]+=p[k];
    return table1[k];
}

int f2(int k){
    //k�� ���� ����
    if (check2[k])
        return table2[k];
    for (int i=0;i<g[k].size();i++)
    {
        j=g[k][i];
        table2[k]+=max(f1(j), f2(j));
    }
    check2[k]=1;
    return table2[k];
}

int main()
{
    cin >> n;
    int i;
    for (i=1;i<=n;i++){
        cin >> p[i];
    }
    int a,b;
    while(1){
        cin >> a >> b;
        if (a==0)
            break;
        g[b].push_back(a);
        check[a]=b;
    }
    int m;
    for (i=1;i<=n;i++)
    {
        if (check[i]==0)
            m=i;
    }
    table1[m]=f1(m);
    table2[m]=f2(m);
    //cout << m << endl;
    cout << max(table1[m], table2[m]);
}
