#include <iostream>
using namespace std;

int t[500];
int n;

int main()
{
    cin >> n;
    int i,j;
    t[0]=1;
    for (i=1;i<=n;i++)
    {
        for (j=0;j<=n;j++){
            t[j+i]=t[j+i]+t[j];
        }
    }
    cout << t[n];
}
