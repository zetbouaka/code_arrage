#include <iostream>
using namespace std;

int n;
int map[111][111];
int table[111][111];
int path[111][111];
int ans;

int main()
{
    cin >> n;
    int i,j,k;
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=n;j++){
            cin >> map[i][j];
        }
    }
    int sum;
    ans=0;
    for (k=1;k<=n;k++)
    {
        for (j=k;j<=n;j++){
            for (i=1;i<=n;i++){
                table[i][j]=table[i][j-1]+map[i][j];
            }
            sum=0;
            for (i=1;i<=n;i++){
                if ((sum+table[i][j])>0){
                    if (sum==0){
                        sum=table[i][j];
                    }else{
                        sum=sum+table[i][j];
                    }
                    if (sum>ans){
                        ans=sum;
                    }
                }else{
                    sum=0;
                }
            }
        }
        for (i=1;i<=n;i++){
            for (j=1;j<=n;j++){
                table[i][j]=0;
            }
        }
    }
    cout << ans;
}
