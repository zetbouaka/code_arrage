#include <iostream>
using namespace std;

int n,m,s;
int g[1111][1111], v[1111], g2[1111][1111], v2[1111];
int q[1111111];

int main()
{
    cin >> n >> m >> s;
    int i,j,a,b,c;
    for (i=1;i<=m;i++){
        cin >> a >> b >> c;
        g[a][b]=c;
        g2[b][a]=c;
    }
    for (i=1;i<=n;i++)
    {
        v[i]=99999999;
        v2[i]=9999999;
    }
    int cnt=1, k;
    q[1]=s;
    v[s]=0;
    k=0;
    while(1){
        k=k+1;
        if (k>cnt)
            break;
        i=q[k];
        for (j=1;j<=n;j++)
        {
            if (g[i][j] && (v[i]+g[i][j])<v[j]){
                cnt++;
                q[cnt]=j;
                v[j]=v[i]+g[i][j];
            }
        }
    }
    cnt=1;
    k=0;
    v2[s]=0;
    while(1){
        k=k+1;
        if (k>cnt)
            break;
        i=q[k];
        for (j=1;j<=n;j++)
        {
            if (g2[i][j] && (v2[i]+g2[i][j])<v2[j]){
                cnt++;
                q[cnt]=j;
                v2[j]=v2[i]+g2[i][j];
            }
        }
    }
    int max=0;
    for (i=1;i<=n;i++){
        if (max<(v[i]+v2[i]))
            max=v[i]+v2[i];
    }
    cout << max;
}
