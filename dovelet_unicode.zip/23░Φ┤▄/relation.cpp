#include <iostream>
using namespace std;

int n,m;
int a,b;
int v[111];
int g[111][111];

void dfs(int k){
    int i;
    for (i=1;i<=n;i++){
        if (g[k][i] && v[i]>v[k]){
            v[i]=v[k]+1;
            dfs(i);
        }
    }
}

int main(){
    cin >> n;
    cin >> a >> b;
    cin >> m;
    int input1,input2;
    int i;
    for (i=0;i<m;i++){
        cin >> input1 >> input2;
        g[input1][input2]=1;
        g[input2][input1]=1;
    }
    for (i=1;i<=n;i++){
        v[i]=999999;
    }
    v[a]=0;
    dfs(a);
    if (v[b]==999999)
        cout << -1;
    else
        cout << v[b];
}
