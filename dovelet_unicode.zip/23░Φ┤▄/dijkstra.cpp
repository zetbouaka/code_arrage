#include <iostream>
using namespace std;

int n,m,s;
int g[1111][1111], v[1111], p[1111];
int q[1111];

void print_path(int u){
    int stack[1111], i=0, k=u;
    while(1)
    {
        i++;
        stack[i]=k;
        k=p[k];
        if (k==0)
            break;
    }
    int j;
    for (j=i;j>=1;j--)
    {
        cout << stack[j] << " ";
    }
    cout << endl;
}

int main()
{
    cin >> n >> m >> s;
    int i,j,a,b,c;
    for (i=1;i<=m;i++){
        cin >> a >> b >> c;
        g[a][b]=c;
    }
    for (i=1;i<=n;i++)
    {
        v[i]=99999999;
    }
    int cnt=1, k;
    q[1]=s;
    v[s]=0;
    p[s]=0;
    k=0;
    while(1){
        k=k+1;
        if (k>cnt)
            break;
        i=q[k];
        for (j=1;j<=n;j++)
        {
            if (g[i][j] && (v[i]+g[i][j])<v[j]){
                cnt++;
                q[cnt]=j;
                v[j]=v[i]+g[i][j];
                p[j]=i;
            }
        }
    }
    for (i=1;i<=n;i++){
        print_path(i);
        //cout << v[i] << endl;
    }
}
