#include <iostream>
using namespace std;

string even="even", odd="odd";

string even_odd(int n)
{
    if (n%2==0)
        return even;
    else
        return odd;
}
int main()
{
    string even="even", odd="odd";
    int n,m;
    string name1,name2;
    cin >> n >> m;
    cout << even_odd(n) << "+" << even_odd(m) << "=" << even_odd(n+m) << endl;
    cout << even_odd(n) << "*" << even_odd(m) << "=" << even_odd(n*m) << endl;
    return 0;
}
