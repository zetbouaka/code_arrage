#include <stdio.h>

int main()
{
    int n;
    double m;
    scanf("%d %lf",&n,&m);
    if (n%5==0)
    {
        if (m-n-0.5>=0)
            m=m-n-0.5;
    }
    printf("%.2lf",m);
    return 0;
}
