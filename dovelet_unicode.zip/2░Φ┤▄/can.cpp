#include <iostream>
using namespace std;

int main()
{
    int n,m;
    cin >> n >> m;
    if (m%2==0)
        cout << "black";
    else
        cout << "white";
    return 0;
}
