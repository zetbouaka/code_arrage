#include <iostream>
using namespace std;

void fun(int array[])
{
    array[1]=1,array[2]=2,array[3]=3;
    //return array[1];
}

void fun2(int a,int b)
{
    b=a+b;
    a=0;
}

int main()
{
    int u[10];
    u[1]=0,u[2]=0,u[3]=0,u[4]=0;
    //cout << fun(u) << endl;
    //fun(u);
    int k=5, y=2;
    cout << k << " " << y << endl;
    fun2(k,y);
    cout << k << " " << y << endl;
    cout << u[1] << endl;
    return 0;
}
