#include <iostream>
using namespace std;

int main()
{
    int n,m;
    cin >> n >> m;
    m=m-45;
    if (m<0)
        m=m+60,n=n-1;
    if (n<0)
        n=n+24;
    cout << n << " " << m;
    return 0;
}
