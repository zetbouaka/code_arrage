#include <iostream>
using namespace std;

int main()
{
    int n,m,flag=0;
    cin >> m >> n;
    if (m==0)
        flag=1;
    if (n==0)
        flag=-1;
    if (flag==1)
    {
        cout << m << " !| " << n;
    }else{
        if (n%m==0 || flag==-1)
            cout << m << " | " << n;
        else
            cout << m << " !| " << n;
    }
    return 0;
}
