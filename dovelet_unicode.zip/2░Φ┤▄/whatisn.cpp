#include <iostream>
using namespace std;

int u[]={0,1,2,2,3,3,3,2,2,1,1};

int main()
{
    int n;
    cin >> n;
    cout << u[n];
    return 0;
}
