#include <iostream>
using namespace std;

int main()
{
    int r,e,c;
    cin >> r >> e >> c;
    if (r==e-c)
        cout << "does not matter";
    else if (r<e-c)
        cout << "advertise";
    else
        cout << "do not advertise";
    return 0;
}
