#include <iostream>
using namespace std;

int sign(int k)
{
    if (k<0)
        return -1;
    if (k>0)
        return 1;
    return 0;
}
int main()
{
    int a,b,c,d;
    cin >> a >> b >> c >> d;
    cout << sign(a*d-b*c);
}
