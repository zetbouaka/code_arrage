#include <iostream>
using namespace std;

int main()
{
    int a,b,c,d;
    cin >> a >> b >> c >> d;
    int sum=0;
    int m1[]={0,461,431,420,0},m2[]={0,130,160,118,0},m3[]={0,100,57,70,0},m4[]={0,167,266,75,0};
    sum=m1[a]+m2[b]+m3[c]+m4[d];
    cout << "Your total Calorie count is " << sum << ".";
}
