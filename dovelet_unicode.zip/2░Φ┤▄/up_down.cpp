#include <iostream>
using namespace std;

int max(int a,int b)
{
    if (a>b)
        return a;
    return b;
}
int abs(int a)
{
    return max(a,-a);
}

int main()
{
    int a,b,c,d,s;
    cin >> a >> b >> c >> d >> s;
    int Ca,Cb,x1,x2;
    Ca=a-b;
    Cb=c-d;
    if (Ca==0 && Cb==0)
    {
        cout << "Tied";
        return 0;
    }
    int Cya=s/(a+b),Cyb=s/(c+d);
    x1=Cya*Ca+max(0,s%(a+b))-max(0,s%(a+b)-a);
    x2=Cyb*Cb+max(0,s%(c+d))-max(0,s%(c+d)-c);
    //cout << x1 <<" " << x2;
    //return 0;
    //x1=abs(x1),x2=abs(x2);
    if (x1>x2)
        cout << "Nikky";
    else if (x1<x2)
        cout << "Byron";
    else
        cout << "Tied";
}
