#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int n,a[3];
    cin >> n;
    cin >> a[0] >> a[1] >> a[2];
    sort(a,a+3);
    int u;
    if (a[0]+a[1]+a[2]-2*n<0)
        u=0;
    else
        u=a[0]+a[1]+a[2]-2*n;
    cout << a[0] << " " << u;
    return 0;
}
