#include <iostream>
using namespace std;

int rotate_cal(int k, int array[5]){
    int newarray[]={0,0,0,0,0},i,j;
    for (i=0;i<k;i++)
    {
        newarray[1]=array[3];
        newarray[2]=array[1];
        newarray[3]=array[4];
        newarray[4]=array[2];
        for (j=1;j<=4;j++)
            array[j]=newarray[j];
    }
    return array[3]*array[4];
}

int main()
{
    int t[5],u[5];
    cin >> t[1] >> t[2] >> t[3] >> t[4];
    u[1]=t[1], u[2]=t[2],u[3]=t[3],u[4]=t[4];
    int maxi=0,max_cal=t[3]*t[4],cal;
    for (int i=0;i<=4;i++)
    {
        cal=rotate_cal(i,t);
        if (max_cal>cal)
        {
            maxi=i;
            max_cal=cal;
        }
        t[1]=u[1],t[2]=u[2],t[3]=u[3],t[4]=u[4];
    }
    cout << maxi;
    return 0;
}
