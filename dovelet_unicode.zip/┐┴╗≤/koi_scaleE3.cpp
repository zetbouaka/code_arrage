#include <iostream>
#include <algorithm>
using namespace std;

int n, sum;
int p[1111];
bool table1[111111111], table2[111111111];

int main(){
    cin >> n;
    int i,j;
    sum=0;
    for (i=0;i<n;i++){
        cin >> p[i];
    }
    sort(p, p+n);
    table1[0]=1;
    for (i=0;i<n;i++){
        sum=sum+p[i];
        for (j=0;j<=sum;j++){
            if (table1[j]){
                table2[j]=1;
                table2[j+p[i]]=1;
            }
        }
        for (j=0;j<=sum;j++){
            table1[j]=table2[j];
            if (table1[j]==0)
            {
                cout << j;
                return 0;
            }
        }
    }
    for (i=1;;i++){
        if (table1[i]==0)
        {
            cout << i;
            return 0;
        }
    }
}
