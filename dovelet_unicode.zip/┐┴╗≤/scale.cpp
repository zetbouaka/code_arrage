#include <stdio.h>
#define O 15000

int n,m;
int table1[30001], table2[30002];
int chu[33];

int main()
{
    int i,j;
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        scanf("%d",&chu[i]);
    }
    //process
    table1[O]=1;
    for (i=1;i<=n;i++)
    {
        for (j=0;j<=30000;j++)
        {
            if (table1[j]>0)
                table2[j+chu[i]]=1, table2[j-chu[i]]=1;
        }
        for (j=0;j<=30000;j++)
        {
            if (table1[j])
                table1[j]=1;
            else
                table1[j]=table2[j];
        }
    }
    //input and output
    scanf("%d",&m);
    int t;
    for (i=0;i<m;i++)
    {
        scanf("%d", &t);
        if (table1[O+t] || table1[O-t])
            printf("Y ");
        else
            printf("N ");
    }
}
