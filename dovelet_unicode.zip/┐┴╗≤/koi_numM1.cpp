#include <iostream>
using namespace std;

long long GCMf(long long a, long long b)
{
    long long c;
    do {
      c=a%b;
      a=b;
      b=c;
    }while(c!=0);
    return a;
}

long long LCMf(long long a, long long b)
{
    return a*b/GCMf(a,b);
}

int main()
{
    long long GCM,LCM;
    cin >> LCM >> GCM;
    long long a,b;
    long long maxa=GCM, maxb=GCM;
    for (long long i=1;i<=GCM;i++){
        a=i;
        b=(LCM*GCM)/a;
        if(GCM%a==0){
            if (LCMf(a,b)==GCM){
                if ((maxa+maxb)>(a+b)){
                    maxa=a;
                    maxb=b;
                }
            }
        }
        if (a>b)
            break;
    }
    cout << maxa << " " << maxb;
}
