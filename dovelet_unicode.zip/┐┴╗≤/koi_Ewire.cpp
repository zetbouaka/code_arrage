#include <iostream>
using namespace std;

int n;
int g1[555], g2[555], table[555];

int main()
{
    cin >> n;
        int i,j,temp;
    for (i=1;i<=n;i++){
        cin >> g1[i] >> g2[i];
    }
    for (i=1;i<=n-1;i++){
        for (j=1;j<=n-i;j++){
            if (g1[j]>g1[j+1]){
                temp=g1[j];
                g1[j]=g1[j+1];
                g1[j+1]=temp;
                temp=g2[j];
                g2[j]=g2[j+1];
                g2[j+1]=temp;
            }
        }
    }
    table[1]=1;
    for (i=2;i<=n;i++){
        table[i]=1;
        for (j=1;j<=i;j++){
            if (table[i]<(table[j]+1) && g2[i]>g2[j]){
                table[i]=table[j]+1;
            }
        }
    }
    int max=-999;
    for (i=1;i<=n;i++){
        if (max<table[i])
            max=table[i];
    }
    cout << n-max;
}
