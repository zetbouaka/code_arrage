#include <iostream>
using namespace std;

int n,m,T;
int table[222];

struct B{
    int color, count;
};

void back(B temp[222], int make_color){

}

int main()
{
    cin >> n >> T;
    int i;
    B bulb[222];
    for (i=0;i<n;i++){
        cin >> table[i];
    }
    int k=table[0],u=0;
    for (i=0;i<=n;i++){
        if (k!=table[i]){
            bulb[m].color=table[i-1];
            bulb[m].count=u;
            u=0;
            k=table[i];
            m++;
        }else{
            u++;
        }
    }
    cout << m;
    for (i=1;i<=k;i++){
        back(bulb, k);
    }
}
